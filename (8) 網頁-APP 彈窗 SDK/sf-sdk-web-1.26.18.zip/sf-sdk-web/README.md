# 弹窗
神策弹窗 SDK 用于配合神策智能运营产品弹窗功能使用。
## 功能
参考官网说明 [Web 弹窗集成](https://manual.sensorsdata.cn/sf/latest/web-32505948.html)，[H5 弹窗集成](https://manual.sensorsdata.cn/sf/latest/h5-22256859.html)
## 注意
- 插件和 SDK 必须在同一个版本中，请勿混合不同版本的 SDK 和插件进行使用。