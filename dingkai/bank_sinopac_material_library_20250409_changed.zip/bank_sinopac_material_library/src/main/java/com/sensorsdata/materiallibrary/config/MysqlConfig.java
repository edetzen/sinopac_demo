package com.sensorsdata.materiallibrary.config;

import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.spring.MybatisSqlSessionFactoryBean;
import com.sensorsdata.airline.guidance.mysql.GuidanceDingKaiMysqlFactory;
import com.sensorsdata.airline.guidance.mysql.GuidanceMysql;
import com.sensorsdata.airline.guidance.mysql.GuidanceMysqlClientConf;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;

/**
 * @author Lx1ngY
 */
@Slf4j
@Configuration
public class MysqlConfig {

  /**
   * 资源name和owner
   */
  private static final String RESOURCE_NAME = "dk_bank_sinopac_material_library_db";
  private static final String RESOURCE_OWNER = "dk_bank_sinopac_material_library";


  @Bean
  @Primary
  @Lazy
  DataSource guidanceDatasource() {
    log.info("create guidanceDatasource");
    //连自己声明的 db
    GuidanceMysql guidanceMysql = GuidanceDingKaiMysqlFactory.create(RESOURCE_OWNER, RESOURCE_NAME);
    return guidanceMysql.getMysqlClient();
  }

  public static GuidanceMysqlClientConf getMysqlConf() {
    return GuidanceDingKaiMysqlFactory.create(RESOURCE_OWNER, RESOURCE_NAME).getConf();
  }


  @Bean
  @Lazy
  public SqlSessionFactory sqlSessionFactory(DataSource adsDataSource, MybatisPlusInterceptor mybatisPlusInterceptor) throws Exception {
    //使用MybatisSqlSessionFactoryBean 可以使用mybatis-BaseMapper中的方法
    final MybatisSqlSessionFactoryBean bean = new MybatisSqlSessionFactoryBean();
    bean.setDataSource(adsDataSource);
    bean.setPlugins(mybatisPlusInterceptor);
    bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mapper/*.xml"));
    return bean.getObject();
  }

}
